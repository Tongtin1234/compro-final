package ticketconcert;

public class Customer {

    private String Name;
    private int age;
    private String gender;
    private String telNumber;

    public Customer(String Name, String telNumber) {
        this.Name = Name;
        this.telNumber = telNumber;
    }

    public String getName() {
        return Name;
    }

    public String getTelNumber() {
        return telNumber;
    }

    @Override
    public String toString() {
        return "Name=" + Name + " TelNumber=" + telNumber + "\n";
    }
}
