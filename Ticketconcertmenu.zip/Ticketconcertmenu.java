package ticketconcert;

import java.util.Scanner;

public class Ticketconcertmenu {

    private Customer c;

    public Ticketconcertmenu(Customer c) {
        this.c = c;
    }

    public void ticketMenu() {
        Scanner input = new Scanner(System.in);
        System.out.println("==========================================");
        System.out.println("====== Welcome to Concert's Ticket ======");
        System.out.println("==========================================");
        System.out.print("1. Seat and Price \n");
        System.out.print("2. Day and time \n");
        System.out.print("3. Buy Ticket \n");
        System.out.print("4. Check Status \n");
        System.out.print("\n == Enter Your Menu Choice : ");
        int menu = input.nextInt();
        switch (menu) {
            case 1:
                seatAndPrice();
                break;
            case 2:
                dayAndTime();
                break;
            case 3:
                buyTicket();
                break;

            case 4:
                checkStatus();
                break;
            default:
                ticketMenu();
        }
    }

    public void seatAndPrice() {
        System.out.println("[Seat and Price]");
        System.out.print(Ticketconcert.getSeatAndPrice());
        ticketMenu();
    }

    public void dayAndTime() {
        System.out.println("[Day and Time]");
        System.out.print(Ticketconcert.getDayAndTime());
        ticketMenu();
    }

    public void buyTicket() {
        Ticketconcert ticket = new Ticketconcert();
        ticket.chooseZone();
        ticketMenu();
    }

    public void checkStatus() {
        Ticketconcert ticket = new Ticketconcert();
        System.out.println(ticket.ticketStatus());
        System.out.println("Name : " + c.getName() + ", Tel : " + c.getTelNumber());
        ticketMenu();
    }

    /*public void Ticketmenu() {
        Scanner input = new Scanner(System.in);
        System.out.println("==========================================");
        System.out.println("====== Welcome to Concert's Ticket ======");
        System.out.println("==========================================");
        System.out.print("1. Seat and Price \n");
        System.out.print("2. Day and time \n");
        System.out.print("3. Buy Ticket \n");
        System.out.print("4. Check Status \n");
        System.out.print("\n == Enter Your Menu Choice : ");
        int menu = input.nextInt();
        switch (menu) {
            case 1:
                System.out.println("[Seat and Price]");
                System.out.print(Ticketconcert.getSeatAndPrice());
                Ticketmenu();
                break;
            case 2:
                System.out.println("[Day and Time]");
                System.out.print(Ticketconcert.getDayAndTime());
                Ticketmenu();
                break;
            case 3:

                System.out.print("Acoount Name : ");
                String accountName = account.nextLine();

                Ticketconcert tk = new Ticketconcert();
                Ticketconcert pt = new Ticketconcert(accountName);
                System.out.println("Your Zone is : " + tk.chooseZone() + " " + "Price Ticket : " + pt.priceticket());

                Ticketconcert dd = new Ticketconcert(accountName);
                Ticketconcert tt = new Ticketconcert(accountName);
                System.out.print("Your day is : " + dd.dateandtime() + " " + "Your Time's Concert is : " + tt.timeconcert());
                System.out.println("Do you want to buy?");
                System.out.println("1. Yes");
                System.out.println("2. No");
                Scanner buy = new Scanner(System.in);
                switch (buy.nextInt()) {
                    case 1:
                        break;
                    case 2:
                        break;
                    default:
                }
                Ticketmenu();
                break;
            case 4:
                System.out.println("[Check Status]");

                break;
            default:
                Ticketmenu();
                break;
        }
    }
//            while (true) {
//                 System.out.println("==Welcome to Concert's Ticket==");
//                 System.out.println("1. Seat and Price \n");
//                 System.out.println("2. Day and time \n");
//                 System.out.println("3. Buy Ticket \n");
//                 System.out.println("4. Check Status \n");
//                 System.out.println("\n==Enter Your Menu Choice : ");
//                 
//            int select_menu = input.nextInt();
//            Ticketconcert tk = new Ticketconcert("test")
//            switch (select_menu) {
//                
//                case 1 : 
//                    
//            }
//            }

    /*public void HowmanyTicket() {
        Scanner input = new Scanner(System.in);
        
            System.out.println("How many Concert Ticket?");
            int amount = input.nextInt();
            if(amount < 1) {
                amount = 1;
            }
            Accout_Name = new String[amount];
            Ticket_Status = new boolean[amount];
            Ticket_price = new int[amount];
            for (int i = 0; i<= amount-1; i++){
                int num = i+1;
                
            }*/
}
